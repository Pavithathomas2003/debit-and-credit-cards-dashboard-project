# dashboard-for-debit-and-credit-cards-project
In this project, I experienced working as a business analyst in the HDFC Bank, one of the top banks in India, helping leadership make decisions. ✅
